# Google Colab Export & Verification Script for YOLO11n to TFLite
# Run this inside Google Colab (Python 3 with GPU or CPU runtime)

"""
STEP 1: Install Ultralytics and dependencies
"""
# !pip install ultralytics tensorflow

import os
from ultralytics import YOLO

print("Loading official YOLO11n PyTorch model...")
model = YOLO("yolo11n.pt")

print("Exporting model to TensorFlow Lite (TFLite) format with 640x640 resolution...")
# Export options:
# - format='tflite': Generates a standard float32 TFLite model
# - imgsz=640: Standard YOLO input resolution
# - int8=False: Float32 for maximum accuracy on Android GPU/CPU
exported_path = model.export(format="tflite", imgsz=640)
print(f"Export completed: {exported_path}")

# In Ultralytics, the export is placed in:
# yolo11n_saved_model/yolo11n_float32.tflite
# Simply rename or copy it to 'yolo11n.tflite' for your Android app:
#
# cp yolo11n_saved_model/yolo11n_float32.tflite yolo11n.tflite
# from google.colab import files
# files.download('yolo11n.tflite')
#
# Then drop it into:
# android-project/app/src/main/assets/yolo11n.tflite