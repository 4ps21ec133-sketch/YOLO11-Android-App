package com.yolo11.detection

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.yolo11.detection.databinding.ActivityMainBinding
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Main Activity for Real-Time YOLO11n Object Detection.
 * Integrates CameraX with on-device TensorFlow Lite inference.
 */
class MainActivity : AppCompatActivity(), Yolo11Detector.DetectorListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private var detector: Yolo11Detector? = null

    private var camera: Camera? = null
    private var cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
    private var isTorchOn = false

    private var frameCount = 0
    private var lastFpsTimestamp = System.currentTimeMillis()
    private var currentFps = 0

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            startCamera()
        } else {
            Toast.makeText(
                this,
                "Camera permission is required for real-time object detection",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()

        initDetector()
        setupControls()

        if (allPermissionsGranted()) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun initDetector() {
        try {
            detector = Yolo11Detector(
                context = this,
                modelPath = "yolo11n.tflite",
                labelPath = "labels.txt",
                detectorListener = this
            )
            binding.tvModelStatus.text = "YOLO11n Active (Local Offline)"
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing detector", e)
            binding.tvModelStatus.text = "Model Error: Place yolo11n.tflite in assets/"
            binding.bannerWarning.visibility = View.VISIBLE
        }
    }

    private fun setupControls() {
        binding.sbConfidence.progress = 40
        binding.tvConfidenceValue.text = "40%"
        binding.sbConfidence.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val conf = progress / 100f
                binding.tvConfidenceValue.text = "$progress%"
                detector?.confidenceThreshold = conf
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnFlipCamera.setOnClickListener {
            cameraSelector = if (cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }
            startCamera()
        }

        binding.btnTorch.setOnClickListener {
            camera?.let { cam ->
                if (cam.cameraInfo.hasFlashUnit()) {
                    isTorchOn = !isTorchOn
                    cam.cameraControl.enableTorch(isTorchOn)
                    binding.btnTorch.alpha = if (isTorchOn) 1.0f else 0.6f
                } else {
                    Toast.makeText(this, "Torch not available", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
                }

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
                .also { analysis ->
                    analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                        processImageProxy(imageProxy)
                    }
                }

            try {
                cameraProvider.unbindAll()
                camera = cameraProvider.bindToLifecycle(
                    this,
                    cameraSelector,
                    preview,
                    imageAnalyzer
                )
            } catch (exc: Exception) {
                Log.e(TAG, "Use case binding failed", exc)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun processImageProxy(imageProxy: ImageProxy) {
        val bitmap = imageProxy.toBitmap()
        val rotationDegrees = imageProxy.imageInfo.rotationDegrees

        detector?.detect(bitmap, rotationDegrees)

        frameCount++
        val now = System.currentTimeMillis()
        if (now - lastFpsTimestamp >= 1000) {
            currentFps = frameCount
            frameCount = 0
            lastFpsTimestamp = now
        }

        imageProxy.close()
    }

    override fun onDetect(boundingBoxes: List<BoundingBox>, inferenceTimeMs: Long) {
        runOnUiThread {
            binding.overlayView.setResults(boundingBoxes)
            binding.tvInferenceTime.text = "${inferenceTimeMs}ms"
            binding.tvObjectCount.text = "${boundingBoxes.size} detected"
            binding.tvFps.text = "$currentFps FPS"
        }
    }

    override fun onEmptyDetect() {
        runOnUiThread {
            binding.overlayView.clear()
            binding.tvObjectCount.text = "0 detected"
            binding.tvFps.text = "$currentFps FPS"
        }
    }

    override fun onError(error: String) {
        runOnUiThread {
            Log.e(TAG, "Detector error: $error")
            binding.tvModelStatus.text = "Error: $error"
        }
    }

    private fun allPermissionsGranted() = ContextCompat.checkSelfPermission(
        baseContext, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    override fun onDestroy() {
        super.onDestroy()
        detector?.close()
        cameraExecutor.shutdown()
    }

    companion object {
        private const val TAG = "MainActivity"
    }
}