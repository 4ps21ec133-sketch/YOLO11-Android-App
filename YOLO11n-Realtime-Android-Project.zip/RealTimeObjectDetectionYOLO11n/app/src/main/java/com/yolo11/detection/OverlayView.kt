package com.yolo11.detection

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * Custom View that overlays bounding boxes, class labels, and confidence percentages
 * directly on top of the CameraX Preview.
 */
class OverlayView(context: Context?, attrs: AttributeSet?) : View(context, attrs) {

    private var results = listOf<BoundingBox>()
    private val boxPaint = Paint()
    private val cornerPaint = Paint()
    private val textBackgroundPaint = Paint()
    private val textPaint = Paint()
    private val textBounds = Rect()

    private val colorPalette = intArrayOf(
        Color.parseColor("#10B981"), // Emerald
        Color.parseColor("#3B82F6"), // Blue
        Color.parseColor("#F59E0B"), // Amber
        Color.parseColor("#EC4899"), // Pink
        Color.parseColor("#8B5CF6"), // Purple
        Color.parseColor("#06B6D4"), // Cyan
        Color.parseColor("#EF4444"), // Red
        Color.parseColor("#14B8A6"), // Teal
        Color.parseColor("#F97316"), // Orange
        Color.parseColor("#84CC16")  // Lime
    )

    init {
        initPaints()
    }

    private fun initPaints() {
        textPaint.color = Color.WHITE
        textPaint.style = Paint.Style.FILL
        textPaint.textSize = 38f
        textPaint.isFakeBoldText = true
        textPaint.isAntiAlias = true

        boxPaint.style = Paint.Style.STROKE
        boxPaint.strokeWidth = 5f
        boxPaint.isAntiAlias = true

        cornerPaint.style = Paint.Style.STROKE
        cornerPaint.strokeWidth = 9f
        cornerPaint.strokeCap = Paint.Cap.ROUND
        cornerPaint.isAntiAlias = true

        textBackgroundPaint.style = Paint.Style.FILL
        textBackgroundPaint.isAntiAlias = true
    }

    fun clear() {
        results = listOf()
        textPaint.reset()
        boxPaint.reset()
        invalidate()
        initPaints()
    }

    fun setResults(boundingBoxes: List<BoundingBox>) {
        results = boundingBoxes
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val viewW = width.toFloat()
        val viewH = height.toFloat()

        for (box in results) {
            val color = colorPalette[box.cls % colorPalette.size]
            boxPaint.color = color
            cornerPaint.color = color

            val left = box.x1 * viewW
            val top = box.y1 * viewH
            val right = box.x2 * viewW
            val bottom = box.y2 * viewH

            val rect = RectF(left, top, right, bottom)

            // Draw Bounding Box Rectangle
            canvas.drawRoundRect(rect, 8f, 8f, boxPaint)

            // Draw Corner Accents
            val cornerLength = minOf(rect.width() * 0.2f, rect.height() * 0.2f, 32f)

            canvas.drawLine(rect.left, rect.top, rect.left + cornerLength, rect.top, cornerPaint)
            canvas.drawLine(rect.left, rect.top, rect.left, rect.top + cornerLength, cornerPaint)

            canvas.drawLine(rect.right, rect.top, rect.right - cornerLength, rect.top, cornerPaint)
            canvas.drawLine(rect.right, rect.top, rect.right, rect.top + cornerLength, cornerPaint)

            canvas.drawLine(rect.left, rect.bottom, rect.left + cornerLength, rect.bottom, cornerPaint)
            canvas.drawLine(rect.left, rect.bottom, rect.left, rect.bottom - cornerLength, cornerPaint)

            canvas.drawLine(rect.right, rect.bottom, rect.right - cornerLength, rect.bottom, cornerPaint)
            canvas.drawLine(rect.right, rect.bottom, rect.right, rect.bottom - cornerLength, cornerPaint)

            // Format Label String
            val confidencePct = (box.cnf * 100).toInt()
            val labelText = "${box.clsName.replaceFirstChar { it.uppercase() }} $confidencePct%"

            textPaint.getTextBounds(labelText, 0, labelText.length, textBounds)
            val textWidth = textBounds.width().toFloat()
            val textHeight = textBounds.height().toFloat()

            val paddingH = 16f
            val paddingV = 10f

            val tagLeft = left
            val tagBottom = if (top - (textHeight + paddingV * 2) >= 0) top - 4f else top + textHeight + paddingV * 2 + 4f
            val tagTop = tagBottom - (textHeight + paddingV * 2)
            val tagRight = tagLeft + textWidth + (paddingH * 2)

            val tagRect = RectF(tagLeft, tagTop, tagRight, tagBottom)

            textBackgroundPaint.color = color
            textBackgroundPaint.alpha = 230
            canvas.drawRoundRect(tagRect, 10f, 10f, textBackgroundPaint)

            canvas.drawText(
                labelText,
                tagLeft + paddingH,
                tagBottom - paddingV - 2f,
                textPaint
            )
        }
    }
}