package com.yolo11.detection

import android.graphics.RectF

data class BoundingBox(
    val x1: Float,
    val y1: Float,
    val x2: Float,
    val y2: Float,
    val cx: Float,
    val cy: Float,
    val w: Float,
    val h: Float,
    val cnf: Float,
    val cls: Int,
    val clsName: String
) {
    fun toRectF(viewWidth: Float, viewHeight: Float): RectF {
        return RectF(
            x1 * viewWidth,
            y1 * viewHeight,
            x2 * viewWidth,
            y2 * viewHeight
        )
    }
}