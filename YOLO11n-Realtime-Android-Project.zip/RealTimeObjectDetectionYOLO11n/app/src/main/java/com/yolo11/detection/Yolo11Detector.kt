package com.yolo11.detection

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.max
import kotlin.math.min

/**
 * High-performance, on-device YOLO11n object detector using TensorFlow Lite.
 *
 * YOLO11n Output Tensor Structure:
 * - Shape: [1, 84, 8400] (where 84 = 4 bounding box coordinates [cx, cy, w, h] + 80 COCO class probabilities)
 * - 8400 candidate anchor predictions across 3 detection strides (8, 16, 32)
 */
class Yolo11Detector(
    private val context: Context,
    private val modelPath: String = "yolo11n.tflite",
    private val labelPath: String = "labels.txt",
    private val detectorListener: DetectorListener
) {

    interface DetectorListener {
        fun onEmptyDetect()
        fun onDetect(boundingBoxes: List<BoundingBox>, inferenceTimeMs: Long)
        fun onError(error: String)
    }

    private var interpreter: Interpreter? = null
    private var labels = mutableListOf<String>()

    // Model configuration
    private val tensorWidth = 640
    private val tensorHeight = 640
    private val numChannels = 3
    private val numElements = 8400 // Total candidate detections
    private val numChannelsOutput = 84 // 4 (x,y,w,h) + 80 classes

    var confidenceThreshold: Float = 0.40f
    var iouThreshold: Float = 0.45f

    init {
        setupModel()
    }

    private fun setupModel() {
        try {
            // 1. Load labels from assets
            loadLabels()

            // 2. Configure Interpreter Options with Hardware Acceleration (GPU / NNAPI)
            val options = Interpreter.Options().apply {
                val compatList = CompatibilityList()
                if (compatList.isDelegateSupportedOnThisDevice) {
                    val delegateOptions = compatList.bestOptionsForThisDevice
                    addDelegate(GpuDelegate(delegateOptions))
                    Log.i(TAG, "YOLO11: Using GPU Delegate for hardware acceleration")
                } else {
                    setNumThreads(4)
                    Log.i(TAG, "YOLO11: Using 4 CPU threads")
                }
            }

            // 3. Load mapped TFLite model buffer
            val modelBuffer = loadModelFile(modelPath)
            interpreter = Interpreter(modelBuffer, options)
            Log.i(TAG, "YOLO11: Interpreter successfully initialized with model $modelPath")

        } catch (e: Exception) {
            Log.e(TAG, "YOLO11: Failed to initialize interpreter", e)
            detectorListener.onError("Failed to load model: ${e.localizedMessage}")
        }
    }

    private fun loadLabels() {
        try {
            val inputStream = context.assets.open(labelPath)
            val reader = BufferedReader(InputStreamReader(inputStream))
            labels.clear()
            var line: String? = reader.readLine()
            while (line != null) {
                if (line.isNotBlank()) {
                    labels.add(line.trim())
                }
                line = reader.readLine()
            }
            reader.close()
            Log.i(TAG, "Loaded ${labels.size} labels from $labelPath")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load labels, using default COCO classes", e)
            labels = arrayListOf(
                "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat",
                "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat",
                "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack",
                "umbrella", "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball",
                "kite", "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket",
                "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple",
                "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake",
                "chair", "couch", "potted plant", "bed", "dining table", "toilet", "tv", "laptop",
                "mouse", "remote", "keyboard", "cell phone", "microwave", "oven", "toaster", "sink",
                "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush"
            )
        }
    }

    private fun loadModelFile(modelName: String): ByteBuffer {
        val fileDescriptor = context.assets.openFd(modelName)
        val inputStream = fileDescriptor.createInputStream()
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    fun detect(frame: Bitmap, rotationDegrees: Int = 0) {
        val tflite = interpreter ?: run {
            detectorListener.onError("Interpreter not initialized")
            return
        }

        val startTime = SystemClock.uptimeMillis()

        // 1. Orient and Preprocess Bitmap to 640x640 Float32 Buffer
        val rotatedBitmap = if (rotationDegrees != 0) {
            val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
            Bitmap.createBitmap(frame, 0, 0, frame.width, frame.height, matrix, true)
        } else {
            frame
        }

        val resizedBitmap = Bitmap.createScaledBitmap(rotatedBitmap, tensorWidth, tensorHeight, true)
        val inputBuffer = bitmapToByteBuffer(resizedBitmap)

        // 2. Prepare Output Buffer [1, 84, 8400]
        val outputBuffer = Array(1) { Array(numChannelsOutput) { FloatArray(numElements) } }

        // 3. Run Inference
        try {
            tflite.run(inputBuffer, outputBuffer)
        } catch (e: Exception) {
            detectorListener.onError("Inference error: ${e.localizedMessage}")
            return
        }

        val inferenceTime = SystemClock.uptimeMillis() - startTime

        // 4. Parse Detections and Apply Non-Maximum Suppression (NMS)
        val detectedBoxes = processOutput(outputBuffer)

        if (detectedBoxes.isEmpty()) {
            detectorListener.onEmptyDetect()
        } else {
            detectorListener.onDetect(detectedBoxes, inferenceTime)
        }
    }

    private fun bitmapToByteBuffer(bitmap: Bitmap): ByteBuffer {
        val byteBuffer = ByteBuffer.allocateDirect(1 * tensorWidth * tensorHeight * numChannels * 4)
        byteBuffer.order(ByteOrder.nativeOrder())
        byteBuffer.rewind()

        val intValues = IntArray(tensorWidth * tensorHeight)
        bitmap.getPixels(intValues, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)

        var pixel = 0
        for (i in 0 until tensorWidth) {
            for (j in 0 until tensorHeight) {
                val value = intValues[pixel++]
                val r = ((value shr 16) and 0xFF) / 255.0f
                val g = ((value shr 8) and 0xFF) / 255.0f
                val b = (value and 0xFF) / 255.0f

                byteBuffer.putFloat(r)
                byteBuffer.putFloat(g)
                byteBuffer.putFloat(b)
            }
        }
        return byteBuffer
    }

    private fun processOutput(output: Array<Array<FloatArray>>): List<BoundingBox> {
        val candidates = mutableListOf<BoundingBox>()

        for (i in 0 until numElements) {
            var maxConfidence = 0.0f
            var maxClassIndex = -1

            for (c in 0 until (numChannelsOutput - 4)) {
                val confidence = output[0][c + 4][i]
                if (confidence > maxConfidence) {
                    maxConfidence = confidence
                    maxClassIndex = c
                }
            }

            if (maxConfidence >= confidenceThreshold && maxClassIndex != -1) {
                val cx = output[0][0][i]
                val cy = output[0][1][i]
                val w = output[0][2][i]
                val h = output[0][3][i]

                val normCx = if (cx > 1.0f) cx / tensorWidth else cx
                val normCy = if (cy > 1.0f) cy / tensorHeight else cy
                val normW = if (w > 1.0f) w / tensorWidth else w
                val normH = if (h > 1.0f) h / tensorHeight else h

                val x1 = max(0.0f, normCx - normW / 2.0f)
                val y1 = max(0.0f, normCy - normH / 2.0f)
                val x2 = min(1.0f, normCx + normW / 2.0f)
                val y2 = min(1.0f, normCy + normH / 2.0f)

                val className = if (maxClassIndex in labels.indices) {
                    labels[maxClassIndex]
                } else {
                    "class_$maxClassIndex"
                }

                candidates.add(
                    BoundingBox(
                        x1 = x1,
                        y1 = y1,
                        x2 = x2,
                        y2 = y2,
                        cx = normCx,
                        cy = normCy,
                        w = normW,
                        h = normH,
                        cnf = maxConfidence,
                        cls = maxClassIndex,
                        clsName = className
                    )
                )
            }
        }

        return applyNMS(candidates)
    }

    private fun applyNMS(boxes: List<BoundingBox>): List<BoundingBox> {
        val sorted = boxes.sortedByDescending { it.cnf }.toMutableList()
        val selected = mutableListOf<BoundingBox>()

        while (sorted.isNotEmpty()) {
            val first = sorted.removeAt(0)
            selected.add(first)

            val iterator = sorted.iterator()
            while (iterator.hasNext()) {
                val next = iterator.next()
                if (first.cls == next.cls) {
                    val iou = calculateIoU(first, next)
                    if (iou >= iouThreshold) {
                        iterator.remove()
                    }
                }
            }
        }

        return selected
    }

    private fun calculateIoU(box1: BoundingBox, box2: BoundingBox): Float {
        val xA = max(box1.x1, box2.x1)
        val yA = max(box1.y1, box2.y1)
        val xB = min(box1.x2, box2.x2)
        val yB = min(box1.y2, box2.y2)

        val intersectionArea = max(0.0f, xB - xA) * max(0.0f, yB - yA)
        val box1Area = (box1.x2 - box1.x1) * (box1.y2 - box1.y1)
        val box2Area = (box2.x2 - box2.x1) * (box2.y2 - box2.y1)

        val unionArea = box1Area + box2Area - intersectionArea
        if (unionArea <= 0.0f) return 0.0f

        return intersectionArea / unionArea
    }

    fun close() {
        interpreter?.close()
        interpreter = null
    }

    companion object {
        private const val TAG = "Yolo11Detector"
    }
}