# Real-Time Object Detection using YOLO11n (Android Kotlin)

An ultra-fast, 100% offline real-time object detection Android application using the **Ultralytics YOLO11n** model in **TensorFlow Lite (TFLite)** format with **Android CameraX**.

---

## ⚡ Highlights
- **100% On-Device & Offline**: Zero network calls or cloud APIs. All inference runs directly on your phone's CPU/GPU via TensorFlow Lite.
- **YOLO11n Architecture**: Specifically tuned for Ultralytics YOLO11 output tensor shape `[1, 84, 8400]` with 80 COCO classes.
- **CameraX Pipeline**: Direct `RGBA_8888` buffer streaming, avoiding slow YUV-to-Bitmap conversion bottlenecks.
- **Hardware Acceleration**: Automatic GPU Delegate detection with fallback to 4-thread CPU inference.
- **Visual HUD**: Real-time bounding box overlay, class name badges, confidence percentages, latency in milliseconds, and live FPS counter.
- **Customizable Controls**: Live slider for Confidence Threshold (10% to 95%), camera flip (back/front), and flash torch toggle.

---

## 📁 Project Structure

```text
RealTimeObjectDetectionYOLO11n/
├── app/
│   ├── src/main/
│   │   ├── java/com/yolo11/detection/
│   │   │   ├── MainActivity.kt       # CameraX lifecycle, permission handling & UI HUD
│   │   │   ├── Yolo11Detector.kt     # TFLite interpreter, pre/post-processing & NMS
│   │   │   ├── OverlayView.kt        # Canvas rendering for bounding boxes & labels
│   │   │   └── BoundingBox.kt        # Data model for detected objects
│   │   ├── assets/
│   │   │   ├── yolo11n.tflite        # <-- PLACE YOUR EXPORTED TFLITE MODEL HERE
│   │   │   └── labels.txt            # 80 COCO dataset class labels
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   └── values/{colors, strings, themes}.xml
│   │   └── AndroidManifest.xml
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

---

## 🚀 Beginner-Friendly Step-by-Step Instructions

### Step 1: Place your `yolo11n.tflite` model
1. Copy your exported `yolo11n.tflite` model file from your Google Colab session.
2. Paste it into the `app/src/main/assets/` folder.
   > The directory should contain:
   > - `app/src/main/assets/yolo11n.tflite`
   > - `app/src/main/assets/labels.txt`

*(If you ever need to re-export in Google Colab, run:*
```python
!pip install ultralytics
from ultralytics import YOLO

model = YOLO("yolo11n.pt")
model.export(format="tflite", imgsz=640)
# This generates 'yolo11n_saved_model/yolo11n_float32.tflite' -> rename to 'yolo11n.tflite'
```
*)*

---

### Step 2: Open Project in Android Studio
1. Download and install [Android Studio](https://developer.android.com/studio) (Ladybug, Koala, Iguana, or newer).
2. Launch Android Studio and click **Open**.
3. Select this `android-project` folder.
4. Wait for Gradle to sync dependencies (CameraX, TensorFlow Lite, Material Design). Android Studio will download the required libraries automatically.

---

### Step 3: Enable USB Debugging on your Android Phone
1. On your physical Android phone, open **Settings** > **About phone**.
2. Tap **Build number** 7 times until you see the message *"You are now a developer!"*.
3. Go back to **Settings** > **System** > **Developer options**.
4. Enable **USB debugging**.
5. Connect your phone to your computer with a USB cable and tap **Allow USB debugging** on your phone's screen.

---

### Step 4: Run the App on your Phone
1. In Android Studio, ensure your connected device appears in the top toolbar device selector.
2. Click the green **Run (▶)** button or press `Shift + F10`.
3. The app will build, install, and launch on your phone.
4. Grant the **Camera Permission** prompt when prompted.
5. Point your camera at objects (people, laptops, cups, chairs, cell phones, cars) and watch real-time bounding boxes appear with confidence scores and latency metrics!

---

### Step 5: How to Build the Standalone `.apk` File
To share or install the APK on any Android phone without Android Studio:
1. In Android Studio's top menu, click **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
2. Android Studio will compile the APK. Once finished, a notification popup will appear at the bottom right with a **locate** link.
3. Click **locate** or open:
   `app/build/outputs/apk/debug/app-debug.apk`
4. Copy `app-debug.apk` to your phone or send it via USB/Drive/Telegram to install and run completely offline!

---

## 🧠 Technical Details: YOLO11n Tensor Structure
- **Input Dimension**: `[1, 640, 640, 3]` (Normalized float32 values between `0.0` and `1.0`).
- **Output Dimension**: `[1, 84, 8400]`
  - Index `0`: Box center X (`cx`)
  - Index `1`: Box center Y (`cy`)
  - Index `2`: Box width (`w`)
  - Index `3`: Box height (`h`)
  - Indices `4` to `83`: Class confidence probabilities for 80 COCO classes (`person`, `bicycle`, `car`, ..., `toothbrush`).
- **NMS**: Non-Maximum Suppression with Intersection over Union (IoU) threshold of 0.45 eliminates duplicate bounding boxes.